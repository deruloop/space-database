package import_csv;

import java.sql.*;

public class DbConnection {
	private String dbURI = "jdbc:postgresql://localhost/my_db";
	private String user = "postgres";
	private String passwd = "postgres";
	
	public Connection getConnection() throws Exception {
		Class.forName("org.postgresql.Driver");
		Connection conn = DriverManager.getConnection(dbURI, user, passwd);
		
		return conn;
	}

}
