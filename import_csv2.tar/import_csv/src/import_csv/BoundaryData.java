package import_csv;

import java.sql.*;

public class BoundaryData {

	public static void main(String[] args) {
		DbConnection db = new DbConnection();
		Connection conn = null;
		String file = "/home/gabriele/Scrivania/ProgettoDb/csv/contorni_filamenti_Herschel.csv";
		String sat = "Herschel";
		
		try {
			conn = db.getConnection();
			
		}catch(Exception e) {
			System.err.println("Connection failed!");
		}
		
		/* importo file csv in una tabella temporanea */
		try {
			String query = "COPY boundary_temp(filament_id, g_long, g_lat) " + 
					       "FROM '" + file + "' " +
					       "DELIMITER ',' CSV HEADER";
			Statement st = conn.createStatement();
			st.executeUpdate(query);
			
		}catch(SQLException e) {
			System.err.println(e.getMessage());
		}	
		
		/* inserisco (aggiorno) i dati relativi */
		try {
			PreparedStatement find_fil = conn.prepareStatement("SELECT * " +
															   "FROM fil_sat " +  
															   "WHERE filament_id = ? and satellite = (SELECT id " + 
																									  "FROM satellite " + 
																									  "WHERE name = '" + sat + "')");
			
			PreparedStatement find_point = conn.prepareStatement("SELECT * " +
																 "FROM boundary " +
																 "WHERE filament_id = ? and filament_name = ? and " + 
																		  "g_pos = (SELECT id FROM g_position WHERE g_lat = ? and g_long = ?)");
			
			PreparedStatement insert_point = conn.prepareStatement("INSERT into boundary VALUES(?,?,(SELECT id FROM g_position WHERE g_lat = ? and g_long = ?))");
			
			
			PreparedStatement find_pos = conn.prepareStatement("SELECT *" +
					   										 "FROM g_position " +
					   										 "WHERE g_lat = ? and g_long = ?");

			PreparedStatement insert_pos = conn.prepareStatement("INSERT into g_position(g_lat, g_long) VALUES(?,?)");
			
			Statement st = conn.createStatement();
			ResultSet rs = st.executeQuery("SELECT * FROM boundary_temp");
			
			while(rs.next()) {
				int fil_id = rs.getInt("filament_id");
				double g_long = rs.getDouble("g_long");
				double g_lat = rs.getDouble("g_lat");
				
				/* inserisco posizione galattica (se non esiste) */
				
				find_pos.setDouble(1, g_lat);
				find_pos.setDouble(2, g_long);
				ResultSet find_p = find_pos.executeQuery();
				
				/* esiste gia' una posizione galattica con suddette coordinate*/
				if (find_p.next()) {
					;
				}
				else {
					insert_pos.setDouble(1, g_lat);
					insert_pos.setDouble(2, g_long);
					
					insert_pos.executeUpdate();
				}
				
				find_fil.setInt(1, fil_id);
				ResultSet find = find_fil.executeQuery();
				
				/* esiste il filamento, si puo' inserire il punto*/
				if (find.next()) {
					String fil_name = find.getString("filament_name");
					
					find_point.setInt(1, fil_id);
					find_point.setString(2, fil_name);
					find_point.setDouble(3, g_lat);
					find_point.setDouble(4, g_long);
					ResultSet find_pt = find_point.executeQuery();
					
					/* esiste gia' il punto del perimetro del suddetto filamento */
					if (find_pt.next()) {
						;
					}
					else {
						insert_point.setInt(1, fil_id);
						insert_point.setString(2, fil_name);
						insert_point.setDouble(3, g_lat);
						insert_point.setDouble(4, g_long);
					
						insert_point.executeUpdate();
					
						System.out.println("Inserted point of (" + fil_id + ", " + fil_name + ")");
					}
				}
				else {
					System.out.println("Filament: " + fil_id + " not founded");
				}
			}	
			
		}catch(SQLException e) {
			System.err.println(e.getMessage());
		}
		
		/* elimino i dati dalla tabella temporanea */
		try {
			Statement st = conn.createStatement();
			st.executeUpdate("DELETE FROM boundary_temp");
			
		}catch(SQLException e) {
			System.err.println(e.getMessage());
		}

	}

}
