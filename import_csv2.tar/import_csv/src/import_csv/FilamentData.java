package import_csv;

import java.sql.*;

public class FilamentData {

	public static void main(String[] args) {
		// TODO Stub di metodo generato automaticamente
		DbConnection db = new DbConnection();
		Connection conn = null;
		String file = "/home/gabriele/Scrivania/ProgettoDb/csv/filamenti_Spitzer.csv";
		
		try {
			conn = db.getConnection();
			
		}catch(Exception e) {
			System.err.println("Connection failed!");
		}
		
		/* importo file csv in una tabella temporanea */
		try {
			String query = "COPY filament_temp " + 
					       "FROM '" + file + "' " +
					       "DELIMITER ',' CSV HEADER";
			Statement st = conn.createStatement();
			st.executeUpdate(query);
			
		}catch(SQLException e) {
			System.err.println(e.getMessage());
		}	
		
		/* inserisco (aggiorno) i dati relativi */
		try {
			PreparedStatement find = conn.prepareStatement("SELECT * " +
														   "FROM filament " +
														   "WHERE id = ? and name = ?");
			
			PreparedStatement insert = conn.prepareStatement("INSERT into filament VALUES(?,?,?,?,?,?,?)");
			
			PreparedStatement update = conn.prepareStatement("UPDATE filament " +
															 "SET total_flux = ?, mean_dens = ?, " +
															     "mean_temp = ?, ellipticity = ?, contrast = ? " +
															 "WHERE id = ? and name = ?");
			
			Statement st = conn.createStatement();
			ResultSet rs = st.executeQuery("SELECT * FROM filament_temp");
			
			while(rs.next()) {
				int filament_id = rs.getInt("id");
				String filament_name = rs.getString("name");
				double total_flux = rs.getDouble("total_flux");
				double mean_dens = rs.getDouble("mean_dens");
				double mean_temp = rs.getDouble("mean_temp");
				double ellipticity = rs.getDouble("ellipticity");
				double contrast = rs.getDouble("contrast");
				String satellite = rs.getString("satellite");
				String instrument = rs.getString("instrument");
				
				/* TODO bisogna gestire satelliti, strumenti e fil_sat*/
				
				find.setInt(1, filament_id);
				find.setString(2, filament_name);
				
				ResultSet fil_find = find.executeQuery();
				
				/* il filamento esiste gia' */
				if (fil_find.next()) {
					update.setDouble(1, total_flux);
					update.setDouble(2, mean_dens);
					update.setDouble(3, mean_temp);
					update.setDouble(4, ellipticity);
					update.setDouble(5, contrast);
					update.setInt(6, filament_id);
					update.setString(7, filament_name);
					
					update.executeUpdate();
					
					System.out.println("Updated filament (" + filament_id + ", " + filament_name + ")");
				}
				/* nuovo filamento */
				else {
					insert.setInt(1, filament_id);
					insert.setString(2, filament_name);
					insert.setDouble(3, total_flux);
					insert.setDouble(4, mean_dens);
					insert.setDouble(5, mean_temp);
					insert.setDouble(6, ellipticity);
					insert.setDouble(7, contrast);
					
					insert.executeUpdate();
					
					System.out.println("Inserted filament (" + filament_id + ", " + filament_name + ")");
				}
			}
			
			
		}catch(SQLException e) {
			System.err.println(e.getMessage());
		}
		
		/* elimino i dati dalla tabella temporanea */
		try {
			Statement st = conn.createStatement();
			st.executeUpdate("DELETE FROM filament_temp");
			
		}catch(SQLException e) {
			System.err.println(e.getMessage());
		}	
	}
}