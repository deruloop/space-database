package import_csv;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class StarData {

	public static void main(String[] args) {
		// TODO Stub di metodo generato automaticamente
		DbConnection db = new DbConnection();
		Connection conn = null;
		String file = "/home/gabriele/Scrivania/ProgettoDb/csv/stelle_Herschel.csv";
		
		try {
			conn = db.getConnection();
			
		}catch(Exception e) {
			System.err.println("Connection failed!");
		}
		
		/* importo file csv in una tabella temporanea */
		try {
			String query = "COPY star_temp " + 
					       "FROM '" + file + "' " +
					       "DELIMITER ',' CSV HEADER";
			Statement st = conn.createStatement();
			st.executeUpdate(query);
			
		}catch(SQLException e) {
			System.err.println(e.getMessage());
		}	
		
		/* inserisco (aggiorno) i dati relativi */
		try {
			PreparedStatement find_s = conn.prepareStatement("SELECT * " +
														     "FROM star " +
														     "WHERE id = ?");
			
			PreparedStatement insert_s = conn.prepareStatement("INSERT into star VALUES(?,?,?,?,(SELECT id FROM g_position WHERE g_lat = ? and g_long = ?))");
			
			PreparedStatement update_s = conn.prepareStatement("UPDATE star " +
															   "SET name = ?, type = ?, " +
															        "flux = ?, g_pos = (SELECT id FROM g_position WHERE g_lat = ? and g_long = ?) " +
															   "WHERE id = ?");
			
			PreparedStatement find_p = conn.prepareStatement("SELECT *" +
					   										 "FROM g_position " +
					   										 "WHERE g_lat = ? and g_long = ?");

			PreparedStatement insert_p = conn.prepareStatement("INSERT into g_position(g_lat, g_long) VALUES(?,?)");
			
			Statement st = conn.createStatement();
			ResultSet rs = st.executeQuery("SELECT * FROM star_temp");
			
			while(rs.next()) {
				int star_id = rs.getInt("id");
				String star_name = rs.getString("name");
				double flux = rs.getDouble("flux");
				double g_long = rs.getDouble("g_long");
				double g_lat = rs.getDouble("g_lat");
				String type = rs.getString("type");
				
				find_p.setDouble(1, g_lat);
				find_p.setDouble(2, g_long);
				ResultSet pos_find = find_p.executeQuery();
				
				/* esiste gia' una posizione galattica con suddette coordinate*/
				if (pos_find.next()) {
					;
				}
				else {
					insert_p.setDouble(1, g_lat);
					insert_p.setDouble(2, g_long);
					
					insert_p.executeUpdate();
				}
				
				
				find_s.setInt(1, star_id);
				ResultSet star_find = find_s.executeQuery();
				
				/* la stella esiste gia' */
				if (star_find.next()) {
					update_s.setString(1, star_name);
					update_s.setString(2, type);
					update_s.setDouble(3, flux);
					update_s.setDouble(4, g_lat);
					update_s.setDouble(5, g_long);
					update_s.setInt(6, star_id);

					update_s.executeUpdate();
					
					System.out.println("Updated star (" + star_id + ", " + star_name + ")");
				}
				/* nuova stella */
				else {
					insert_s.setInt(1, star_id);
					insert_s.setString(2, star_name);
					insert_s.setString(3, type);
					insert_s.setDouble(4, flux);
					insert_s.setDouble(5, g_lat);
					insert_s.setDouble(6, g_long);
					
					insert_s.executeUpdate();
					
					System.out.println("Inserted star (" + star_id + ", " + star_name + ")");
				}
			}
			
			
		}catch(SQLException e) {
			System.err.println(e.getMessage());
		}
		
		/* elimino i dati dalla tabella temporanea */
		try {
			Statement st = conn.createStatement();
			st.executeUpdate("DELETE FROM star_temp");
			
		}catch(SQLException e) {
			System.err.println(e.getMessage());
		}	

	}

}